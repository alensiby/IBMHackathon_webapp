import firebase from "firebase/compat/app"
import "firebase/compat/auth"
const firebaseConfig= firebase.initializeApp({
    apiKey: "AIzaSyBqZdaTFqsMxlucopNqgDeIaDDkS-o8XVg",
    authDomain: "ibmhackathon-349f6.firebaseapp.com",
    projectId: "ibmhackathon-349f6",
    storageBucket: "ibmhackathon-349f6.appspot.com",
    messagingSenderId: "1094635963382",
    appId: "1:1094635963382:web:fba61ab60fd5d837d8fdd7",
    databaseURL: 'https://ibmhackathon-349f6.firebaseio.com',
})
  
export const auth=firebaseConfig.auth();


export default firebaseConfig;