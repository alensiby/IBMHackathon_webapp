import React from "react";
import "./App.css";
import { Routes, Route } from "react-router-dom";
import LogIn from "./components/LoginandSignup/LogIn";
import {  useAuth } from "./AuthContext";
import Structure from "./components/Layout/Structure";
import Dashboard from "./components/Dashboard/Dashboard";
import AppoinmentStatus from "./components/Appoinment/AppoinmentStatus";
import OnlineMustering from "./components/OnlinrMustering/OnlineMustering";
export const AuthContext = React.createContext(null);
function App() {
  const { currentUser } = useAuth();
  
  
  return (
    <>
       
      {
      currentUser ? 
      
     <Structure>
       <Routes>
          <Route  path="/Dashboard" element={<Dashboard/>}></Route>
          <Route  path="/AppoinmentStatus" element={<AppoinmentStatus/>}></Route>
          <Route  path="/OnlineMustering" element={<OnlineMustering/>}></Route>
       
       </Routes>
      </Structure> 
      :
      <Routes>
        <Route exact path="/Login" element={<LogIn/>}></Route>
      </Routes>
      
    
      
      }
     </>

   
   
  );
}

export default App;
