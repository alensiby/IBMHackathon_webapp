import React from 'react'

import { Menu } from "antd";
import { Link } from "react-router-dom";
import "./sidebar.css"
import {MdOutlineSpaceDashboard,MdOutlineDomainVerification} from "react-icons/md"
import{BsBookmarkCheck} from "react-icons/bs"
const {SubMenu}=Menu;

export default function Navbar(props) {
  return (
    <div className='side-menu'>
       <div className="logo">
        {!props.compact && <div className="Cname">Govt of Kerala</div>}
      </div>
   <Menu theme="dark" defaultSelectedKeys={["1"]} mode="vertical">
       <Menu.Item key="1"  icon={<MdOutlineSpaceDashboard />}>
         <Link to="/Dashboard"/>
           Dashboard
       </Menu.Item>
       <Menu.Item key="2" icon={<BsBookmarkCheck/>}>
       <Link to="/AppoinmentStatus"/>
           Appoinment Status
       </Menu.Item>
       <Menu.Item key="3" icon={<MdOutlineDomainVerification/>} >
       <Link to="/OnlineMustering"/>
           Online Mustering
       </Menu.Item>
   </Menu>
</div>
  )
}
