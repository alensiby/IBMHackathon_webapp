import React,{useState} from "react";
import "./layout.css";
import {  useNavigate } from "react-router-dom"
import { useAuth } from "../../AuthContext";


export default function HeaderBar() {
  const [error, setError] = useState("")
  const {logout}=useAuth()
  const navigate = useNavigate()

  async function handleLogout() {
    setError("")

    try {
      await logout()
      navigate("/Login")
    } catch {
      setError("Failed to log out")
    }
  }

  return (
    <div className="header">
      <div className="logoName" style={{ color: "rgb(79, 79, 79)" }}>
        <b>Govt</b> Authority
      </div>
      <div className="spacer"></div>
      <span className="userDetails">User Name </span> 
      <button className="logout" onClick={handleLogout}>Logout</button>
    </div>
  );
}