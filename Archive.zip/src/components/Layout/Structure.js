import React,{useState} from 'react'
import { Layout, Menu, MenuProps } from 'antd';
import 'antd/dist/antd.css';
import "./layout.css";
import Navbar from './Navbar';
import HeaderBar from './Headerbar';
const { Header, Content, Sider } = Layout;
export default function Structure({children}) {
    const [collapsed, setcollapsed] = useState(false);

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider 
       collapsible  collapsed={collapsed} onCollapse={setcollapsed} >
      <Navbar compact={collapsed}></Navbar>
      </Sider>
      <Layout className="site-layout">
        <Header className="site-layout-background" style={{ padding: 0,height:'62px',backgroundColor:'#dcdcdc' }} >
          <HeaderBar/>
        </Header>
        <Content style={{ backgroundColor:'white' ,overflow:'auto',maxHeight:'-webkit-fill-available'}}>
          {children}
        </Content>
      </Layout>
    </Layout>
  )
}
