import React from 'react'
import { Card,Container,Row,Col,Button} from 'react-bootstrap';
import {collection, doc,getFirestore,onSnapshot} from "firebase/firestore";
let appointments=[]
export default function OnlineMustering(){
  const db=getFirestore();
  const colref=collection(db,'OnlineMustering')
  var len=0
  
 
  onSnapshot(colref, (snapshot) => {
    appointments=[]
    snapshot.docs.forEach((doc)=>{
      
      appointments.push({ ...doc.data()})

    })
   
    len=appointments.length
    console.log(appointments)
  })
  return (

        <>
       
          {
          appointments.map((a)=>{
            
            return(
                
              <Row xs={3}>
              <Col>
              <Card>
              <Card.Img variant="top"  />
              <Card.Body>
                <Card.Title >{a.Name}</Card.Title>
                <Button variant="primary">View Applicant</Button>
                </Card.Body>
              </Card>
              </Col>
              </Row>
            )

          })
          }

        </>
  )
}
